/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask4;
import java.util.Scanner;
/**
 *
 * @author Josh
 */
public class ICETask4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
    Scanner scan = new Scanner(System.in);
        
        
        System.out.print("Enter the number of salespeople: ");
        final int SALESPEOPLE = scan.nextInt();
        
        int[] sales = new int[SALESPEOPLE];
        int sum = 0;
        int maxSale = Integer.MIN_VALUE;
        int minSale = Integer.MAX_VALUE;
        int maxSaleId = -1;
        int minSaleId = -1;

        
        for (int i = 0; i < sales.length; i++) {
            System.out.print("Enter sales for salesperson " + (i + 1) + ": ");
            sales[i] = scan.nextInt();
            sum += sales[i];

            if (sales[i] > maxSale) {
                maxSale = sales[i];
                maxSaleId = i + 1; 
            }
            if (sales[i] < minSale) {
                minSale = sales[i];
                minSaleId = i + 1; 
            }
        }

        
        System.out.println("\nSalesperson Sales");
        System.out.println("--------------------");
        for (int i = 0; i < sales.length; i++) {
            System.out.println(" " + (i + 1) + " " + sales[i]); 
        }

        
        System.out.println("\nTotal sales: " + sum);
        double average = (double) sum / SALESPEOPLE;
        System.out.println("Average sales: " + average);

        
        System.out.println("Salesperson " + maxSaleId + " had the highest sale with $" + maxSale + ".");
        System.out.println("Salesperson " + minSaleId + " had the lowest sale with $" + minSale + ".");

        
        System.out.print("\nEnter a value to compare sales: ");
        int value = scan.nextInt();
        int countExceeding = 0;

        System.out.println("Salespeople who exceeded " + value + ":");
        for (int i = 0; i < sales.length; i++) {
            if (sales[i] > value) {
                System.out.println("Salesperson " + (i + 1) + " with sales $" + sales[i]);
                countExceeding++;
            }
        }
        System.out.println("Total number of salespeople who exceeded " + value + ": " + countExceeding);
    }   
    }
    

